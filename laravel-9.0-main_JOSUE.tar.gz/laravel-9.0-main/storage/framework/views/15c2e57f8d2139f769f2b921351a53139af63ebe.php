<?php $__env->startSection('content'); ?>

<div class="container">
    <h1 class="mb-4">Películas Destacadas</h1>
    <div class="row">
        <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card mb-3">
                    <img src="<?php echo e($movie->image); ?>" class="card-img-top" alt="<?php echo e($movie->title); ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($movie->title); ?></h5>
                        <p class="card-text"><?php echo e(Str::limit($movie->description, 100)); ?></p>
                        <p><strong>Género:</strong> <?php echo e($movie->genre); ?></p>
                        <p><strong>Año:</strong> <?php echo e($movie->year); ?></p>
                        <a href="#" class="btn btn-primary">Ver Película</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.disenyo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/home.blade.php ENDPATH**/ ?>